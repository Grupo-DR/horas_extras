
import { db } from '@/services/firebaseConfig';
import { collection, doc, writeBatch, query, where, getDocs, addDoc, Timestamp, getDoc, setDoc, deleteDoc } from 'firebase/firestore';
import { BudgetRecord, SalaryAllocation, PlanningRecord, UserProfile, ManualEmployee, HeadcountRecord, HeadcountUploadMeta } from '../types';
import { Scope } from '../../iam/types';
import { isCostCenterInHumanCapitalScope } from '../utils/scopeFilters';

const COL_BUDGETS = 'hc_budgets';
const COL_SALARIES = 'hc_salary_allocations';
const COL_PLANNING = 'hc_planning_records';
const COL_AUDIT = 'hc_audit_logs';
const COL_HEADCOUNT = 'hc_headcount';

interface LegacyWorkTeam {
    id: string;
    name: string;
    costCenter: string;
    managerName?: string;
    memberChapas?: string[];
}

interface LegacyTeamAllocation {
    id: string;
    teamId: string;
    monthKey: string;
    chapas: string[];
}

// --- BUDGETS ---

// --- HELPERS ---

const safeNumber = (v: any): number => {
    const n = Number(v);
    return isNaN(n) ? 0 : n;
};

const clean = (obj: any): any => {
    if (!obj) return obj;
    const res: any = {};
    Object.keys(obj).forEach(key => {
        const val = obj[key];
        if (val !== undefined) {
            res[key] = val;
        }
    });
    return res;
};

// --- BUDGETS ---

export const upsertBudgets = async (budgets: BudgetRecord[], user: UserProfile) => {
    const batch = writeBatch(db);
    budgets.forEach(b => {
        // ID: budget_YYYY-MM_CC_normalized
        if (!b.monthKey) return; // Guard clause
        const id = `budget_${b.monthKey}_${b.costCenter}`;
        const ref = doc(db, COL_BUDGETS, id);

        const data = clean({
            ...b,
            value: safeNumber(b.value)
        });

        batch.set(ref, {
            ...data,
            updatedAt: Timestamp.now(),
            updatedBy: user.email
        }, { merge: true });
    });
    await batch.commit();
};

export const getBudgetsByMonthKey = async (monthKey: string, scope?: Scope) => {
    if (!monthKey) return [];
    const q = query(collection(db, COL_BUDGETS), where('monthKey', '==', monthKey));
    const snapshot = await getDocs(q);
    return snapshot.docs
        .map(d => d.data() as BudgetRecord)
        .filter(b => isCostCenterInHumanCapitalScope(scope, b.costCenter || ''));
};

export const getAllBudgets = async (scope?: Scope): Promise<BudgetRecord[]> => {
    const snapshot = await getDocs(collection(db, COL_BUDGETS));
    return snapshot.docs
        .map(d => d.data() as BudgetRecord)
        .filter(b => isCostCenterInHumanCapitalScope(scope, b.costCenter || ''));
};

export const deleteBudgetsByMonthKey = async (monthKey: string): Promise<void> => {
    if (!monthKey) return;
    const q = query(collection(db, COL_BUDGETS), where('monthKey', '==', monthKey));
    const snapshot = await getDocs(q);
    const batch = writeBatch(db);
    snapshot.docs.forEach(d => batch.delete(d.ref));
    await batch.commit();
};

export const deleteAllBudgets = async (): Promise<void> => {
    const snapshot = await getDocs(collection(db, COL_BUDGETS));
    // Firestore batch limit is 500; chunk if needed
    const CHUNK = 400;
    for (let i = 0; i < snapshot.docs.length; i += CHUNK) {
        const batch = writeBatch(db);
        snapshot.docs.slice(i, i + CHUNK).forEach(d => batch.delete(d.ref));
        await batch.commit();
    }
};

// --- SALARIES ---

export const upsertSalaryAllocations = async (allocations: SalaryAllocation[], user: UserProfile) => {
    // Batches limited to 500. Assuming import isn't huge, or we slice.
    // For now, let's slice just in case.
    const chunks = [];
    for (let i = 0; i < allocations.length; i += 400) {
        chunks.push(allocations.slice(i, i + 400));
    }

    for (const chunk of chunks) {
        const batch = writeBatch(db);
        chunk.forEach(s => {
            // ID: salary_YYYY-MM_CHAPA_CC
            if (!s.monthKey || !s.chapa) return; // Guard
            const id = `salary_${s.monthKey}_${s.chapa}_${s.costCenter}`;
            const ref = doc(db, COL_SALARIES, id);

            const data = clean({
                ...s,
                salary: safeNumber(s.salary),
                allocation: safeNumber(s.allocation)
            });

            batch.set(ref, {
                ...data,
                updatedAt: Timestamp.now(),
                updatedBy: user.email
            }, { merge: true });
        });
        await batch.commit();
    }
};

export const getSalaryAllocationsByMonthKey = async (monthKey: string, scope?: Scope) => {
    if (!monthKey) return [];
    const q = query(collection(db, COL_SALARIES), where('monthKey', '==', monthKey));
    const snapshot = await getDocs(q);
    return snapshot.docs
        .map(d => d.data() as SalaryAllocation)
        .filter(s => isCostCenterInHumanCapitalScope(scope, s.costCenter || ''));
};

export const deleteSalaryAllocationsByMonthKeys = async (monthKeys: string[]): Promise<void> => {
    const keys = Array.from(new Set((monthKeys || []).filter(Boolean)));
    if (keys.length === 0) return;

    for (const monthKey of keys) {
        const q = query(collection(db, COL_SALARIES), where('monthKey', '==', monthKey));
        const snapshot = await getDocs(q);
        const CHUNK = 400;

        for (let i = 0; i < snapshot.docs.length; i += CHUNK) {
            const batch = writeBatch(db);
            snapshot.docs.slice(i, i + CHUNK).forEach(d => batch.delete(d.ref));
            await batch.commit();
        }
    }
};

// --- PLANNING ---

export const upsertPlanningRecords = async (records: PlanningRecord[], user: UserProfile) => {
    const batch = writeBatch(db);
    records.forEach(r => {
        // ID: Use r.id if present, or construct
        // ID: plan_YYYY-MM-DD_CHAPA_CC_TYPE
        if (!r.date || !r.chapa) return;
        const id = r.id || `plan_${r.date}_${r.chapa}_${r.costCenter}_${r.type}`;
        const ref = doc(db, COL_PLANNING, id);

        const data = clean({
            ...r,
            plannedHours: safeNumber(r.plannedHours)
        });

        batch.set(ref, {
            ...data,
            id, // ensure ID is saved
            updatedAt: Timestamp.now(),
            updatedBy: user.email
        }, { merge: true });
    });
    await batch.commit();
};

export const getPlanningRecords = async (monthKey: string, type: 'DAILY' | 'MONTHLY', scope?: Scope) => {
    // Note: We need to filter by month start.
    // 'date' field is string 'YYYY-MM-DD' or 'YYYY-MM'.
    // Firestore string prefix matching usually via >= and <=
    const start = monthKey;
    const end = monthKey + '\uf8ff';

    // We also need to match TYPE.
    // Compound query requires index. If fails, we might filter in memory.
    // Let's try compound.
    const q = query(
        collection(db, COL_PLANNING),
        where('date', '>=', start),
        where('date', '<=', end),
        where('type', '==', type)
    );

    // If index missing, this might fail console.error.
    // We can just query by date and filter type in memory, safer for now without deploying indexes manually.
    // Actually, 'date' is enough to narrow down to month.

    const q2 = query(
        collection(db, COL_PLANNING),
        where('date', '>=', start),
        where('date', '<=', end)
    );

    const snapshot = await getDocs(q2);
    const all = snapshot.docs.map(d => d.data() as PlanningRecord);
    return all.filter(r => r.type === type && isCostCenterInHumanCapitalScope(scope, r.costCenter || ''));
};

// --- AUDIT ---

export const writeAudit = async (action: string, meta: any, user: UserProfile) => {
    try {
        await addDoc(collection(db, COL_AUDIT), {
            action,
            metadata: meta,
            userEmail: user.email,
            timestamp: Timestamp.now()
        });
    } catch (e) {
        console.error("Audit Log Failed", e);
    }
};
// --- TEAMS ---

const COL_TEAMS = 'hc_teams';

export const upsertTeams = async (teams: LegacyWorkTeam[], user: UserProfile) => {
    const batch = writeBatch(db);
    teams.forEach(t => {
        if (!t.id) return;
        const ref = doc(db, COL_TEAMS, t.id);

        batch.set(ref, {
            ...t,
            updatedAt: Timestamp.now(),
            updatedBy: user.email
        }, { merge: true });
    });
    await batch.commit();
};

export const getTeams = async (scope?: Scope) => {
    const q = query(collection(db, COL_TEAMS));
    // Filters based on scope can be added here if needed, currently global or filtered in UI
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => d.data() as LegacyWorkTeam);
};

export const deleteTeam = async (teamId: string) => {
    if (!teamId) return;
    await deleteDoc(doc(db, COL_TEAMS, teamId));
};

// --- TEAM ALLOCATIONS ---

const COL_TEAM_ALLOCATIONS = 'hc_team_allocations';

export const upsertTeamAllocation = async (allocation: LegacyTeamAllocation, user: UserProfile) => {
    if (!allocation.id) return;
    const ref = doc(db, COL_TEAM_ALLOCATIONS, allocation.id);
    await setDoc(ref, {
        ...allocation,
        updatedAt: Timestamp.now(),
        updatedBy: user.email
    }, { merge: true });
};

export const getTeamAllocationsByMonthKey = async (monthKey: string, scope?: Scope) => {
    if (!monthKey) return [];
    const q = query(collection(db, COL_TEAM_ALLOCATIONS), where('monthKey', '==', monthKey));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => d.data() as LegacyTeamAllocation);
};

export const getAllTeamAllocations = async () => {
    const q = query(collection(db, COL_TEAM_ALLOCATIONS));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => d.data() as LegacyTeamAllocation);
};

// --- MANUAL EMPLOYEES ---

const COL_MANUAL_EMPLOYEES = 'hc_manual_employees';

export const upsertManualEmployee = async (employee: ManualEmployee, user: UserProfile) => {
    if (!employee.id) return;
    const ref = doc(db, COL_MANUAL_EMPLOYEES, employee.id);
    await setDoc(ref, {
        ...employee,
        updatedAt: Timestamp.now(),
        updatedBy: user.email
    }, { merge: true });
};

export const getManualEmployees = async () => {
    const q = query(collection(db, COL_MANUAL_EMPLOYEES));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => d.data() as ManualEmployee);
};

// --- GLOBAL EMPLOYEES (DICTIONARY) ---

const COL_GLOBAL_EMPLOYEES = 'hc_global_employees';

export const upsertGlobalEmployees = async (employees: import('../types').GlobalEmployee[], user: UserProfile) => {
    // Batches limited to 500.
    const chunks = [];
    for (let i = 0; i < employees.length; i += 400) {
        chunks.push(employees.slice(i, i + 400));
    }

    for (const chunk of chunks) {
        const batch = writeBatch(db);
        chunk.forEach(emp => {
            if (!emp.chapa) return;
            const ref = doc(db, COL_GLOBAL_EMPLOYEES, emp.chapa);
            batch.set(ref, {
                ...emp,
                updatedAt: Timestamp.now(),
                updatedBy: user.email
            }, { merge: true });
        });
        await batch.commit();
    }
};

export const getGlobalEmployees = async () => {
    const q = query(collection(db, COL_GLOBAL_EMPLOYEES));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => d.data() as import('../types').GlobalEmployee);
};

// --- HEADCOUNT ---

/**
 * Salva (upsert) registros de headcount no Firestore.
 * ID composto: hc_{uploadId}_{chapa}_{centroCusto}_{dataInicio}
 */
export const upsertHeadcountRecords = async (
    records: HeadcountRecord[],
    meta: HeadcountUploadMeta,
    user: UserProfile
): Promise<void> => {
    const CHUNK = 400;
    for (let i = 0; i < records.length; i += CHUNK) {
        const batch = writeBatch(db);
        records.slice(i, i + CHUNK).forEach(r => {
            const id = `hc_${meta.uploadId}_${r.chapa}_${r.centroCusto}_${r.dataInicio}`;
            const ref = doc(db, COL_HEADCOUNT, id);
            batch.set(ref, {
                ...r,
                uploadId: meta.uploadId,
                uploadedAt: meta.uploadedAt,
                updatedAt: Timestamp.now(),
                updatedBy: user.email,
            }, { merge: true });
        });
        await batch.commit();
    }
    await writeAudit('HEADCOUNT_UPLOAD', {
        uploadId: meta.uploadId,
        recordCount: meta.recordCount,
        uploadedAt: meta.uploadedAt,
    }, user);
};

/**
 * Retorna todos os registros de headcount.
 * Se dateRef for fornecido, filtra pelos registros vigentes naquela data.
 */
export const getHeadcountRecords = async (dateRef?: string): Promise<HeadcountRecord[]> => {
    const q = query(collection(db, COL_HEADCOUNT));
    const snapshot = await getDocs(q);
    const all = snapshot.docs.map(d => d.data() as HeadcountRecord & { uploadId?: string });
    if (!dateRef) return all;
    return all.filter(r => r.dataInicio <= dateRef && r.dataFim >= dateRef);
};

/**
 * Remove todos os registros de headcount de um uploadId específico.
 */
export const deleteHeadcountByUploadId = async (uploadId: string): Promise<void> => {
    const q = query(collection(db, COL_HEADCOUNT), where('uploadId', '==', uploadId));
    const snapshot = await getDocs(q);
    const CHUNK = 400;
    for (let i = 0; i < snapshot.docs.length; i += CHUNK) {
        const batch = writeBatch(db);
        snapshot.docs.slice(i, i + CHUNK).forEach(d => batch.delete(d.ref));
        await batch.commit();
    }
};

/**
 * [REPLACE MODE - ETAPA A]
 * Remove TODOS os registros de headcount da colecao hc_headcount, sem filtro por uploadId.
 * Garante que nenhum headcount residual de uploads anteriores permaneca ativo.
 */
export const clearAllHeadcountRecords = async (): Promise<void> => {
    const snapshot = await getDocs(collection(db, COL_HEADCOUNT));
    if (snapshot.empty) return;
    const CHUNK = 400;
    for (let i = 0; i < snapshot.docs.length; i += CHUNK) {
        const batch = writeBatch(db);
        snapshot.docs.slice(i, i + CHUNK).forEach(d => batch.delete(d.ref));
        await batch.commit();
    }
};

/**
 * [REPLACE MODE - OPERACAO PRINCIPAL]
 * Substitui COMPLETAMENTE o headcount no Firestore.
 *
 * Etapa A - Remove todos os registros existentes (clearAllHeadcountRecords).
 * Etapa B - Insere os novos registros em batch sem merge (escrita limpa).
 * Etapa C - Grava log de auditoria com action 'HEADCOUNT_REPLACE'.
 *
 * IDs de documento nao incluem uploadId para evitar acumulo entre uploads.
 * Nunca ha dois conjuntos de headcount coexistentes apos esta operacao.
 */
export const replaceHeadcountRecords = async (
    records: HeadcountRecord[],
    meta: HeadcountUploadMeta,
    user: UserProfile
): Promise<void> => {
    // Etapa A: remocao total
    await clearAllHeadcountRecords();

    // Etapa B: insercao do novo lote sem merge
    const CHUNK = 400;
    for (let i = 0; i < records.length; i += CHUNK) {
        const batch = writeBatch(db);
        records.slice(i, i + CHUNK).forEach(r => {
            // ID deterministico sem prefixo de uploadId para evitar acumulo
            const id = `hc_${r.chapa}_${r.centroCusto}_${r.dataInicio}`;
            const ref = doc(db, COL_HEADCOUNT, id);
            batch.set(ref, {
                ...r,
                uploadId: meta.uploadId,
                uploadedAt: meta.uploadedAt,
                updatedAt: Timestamp.now(),
                updatedBy: user.email,
            });
        });
        await batch.commit();
    }

    // Etapa C: auditoria
    await writeAudit('HEADCOUNT_REPLACE', {
        uploadId: meta.uploadId,
        recordCount: meta.recordCount,
        uploadedAt: meta.uploadedAt,
        replacedAt: new Date().toISOString(),
    }, user);
};
